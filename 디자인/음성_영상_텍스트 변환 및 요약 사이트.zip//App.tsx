import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Input } from './components/ui/input';
import { Textarea } from './components/ui/textarea';
import { Badge } from './components/ui/badge';
import { 
  Upload, 
  FileAudio, 
  FileVideo, 
  FileText, 
  Youtube, 
  Zap, 
  BookOpen,
  Menu,
  Home,
  Settings,
  HelpCircle,
  Bell,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { convertSpeechToText, isAudioOrVideoFile, getFileTypeDescription } from './utils/clova-api';

export default function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [textInput, setTextInput] = useState('');
  const [conversionResult, setConversionResult] = useState('');
  const [summaryResult, setSummaryResult] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [conversionError, setConversionError] = useState<string | null>(null);
  const [conversionSuccess, setConversionSuccess] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setConversionError(null);
      setConversionResult('');
      setConversionSuccess(false);
    }
  };

  const handleConvert = async () => {
    setIsConverting(true);
    setConversionError(null);
    setConversionSuccess(false);

    try {
      if (selectedFile && isAudioOrVideoFile(selectedFile)) {
        // 실제 CLOVA API 호출
        const result = await convertSpeechToText(selectedFile);
        setConversionResult(result.text);
        setConversionSuccess(true);
      } else if (textInput.trim()) {
        // 텍스트 입력의 경우 그대로 표시
        setConversionResult(textInput);
        setConversionSuccess(true);
      } else if (youtubeUrl.trim()) {
        // YouTube URL의 경우 현재는 Mock 응답 (실제 구현 시 YouTube API 필요)
        setConversionResult(`YouTube 영상 처리 기능은 현재 개발 중입니다.
        
입력된 URL: ${youtubeUrl}

실제 구현을 위해서는 YouTube Data API를 통해 자막을 추출하거나, 
영상을 다운로드하여 음성을 추출한 후 CLOVA API로 변환하는 과정이 필요합니다.`);
        setConversionSuccess(true);
      } else {
        throw new Error('변환할 파일을 선택하거나 텍스트를 입력해주세요.');
      }
    } catch (error) {
      console.error('변환 오류:', error);
      setConversionError(error instanceof Error ? error.message : '알 수 없는 오류가 발생했습니다.');
      setConversionResult('');
    } finally {
      setIsConverting(false);
    }
  };

  const handleSummarize = async () => {
    if (!conversionResult && !textInput) return;
    
    setIsSummarizing(true);
    
    try {
      // Mock summarization process - 실제로는 ChatGPT API나 다른 요약 API 사용
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const textToSummarize = conversionResult || textInput;
      const mockSummary = `📋 AI 요약 결과

🔍 주요 내용:
• ${textToSummarize.length > 100 ? '긴 텍스트' : '짧은 텍스트'}가 입력되었습니다
• 총 ${textToSummarize.split(/\s+/).filter(word => word.length > 0).length}개의 단어로 구성
• ${textToSummarize.split(/[.!?]+/).filter(s => s.trim().length > 0).length}개의 문장 포함

🎯 핵심 포인트:
• 텍스트 길이: ${textToSummarize.length}자
• 예상 읽기 시간: 약 ${Math.max(1, Math.ceil(textToSummarize.length / 200))}분
• 주요 키워드가 포함된 내용

💡 요약:
입력된 텍스트의 주요 내용을 분석하여 핵심 정보를 추출했습니다. 더 정확한 요약을 위해서는 실제 AI 요약 API 연동이 필요합니다.`;
      
      setSummaryResult(mockSummary);
    } catch (error) {
      console.error('요약 오류:', error);
      setSummaryResult('요약 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setIsSummarizing(false);
    }
  };

  const getFileIcon = (file: File | null) => {
    if (!file) return <Upload className="h-4 w-4" />;
    
    if (file.type.startsWith('audio/')) return <FileAudio className="h-4 w-4" />;
    if (file.type.startsWith('video/')) return <FileVideo className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      // 성공 피드백을 위한 임시 상태 변경 (실제로는 toast 사용 권장)
      console.log('클립보드에 복사되었습니다.');
    } catch (err) {
      console.error('복사 실패:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#6366f1] via-[#8b5cf6] to-[#a855f7] relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-300 rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-300 rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="relative z-10 flex h-screen">
        {/* Sidebar */}
        <div className="w-64 bg-white/10 backdrop-blur-sm border-r border-white/20 p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-white">SmartNote</h1>
              <p className="text-white/60 text-sm">AI 변환 &amp; 요약</p>
            </div>
          </div>

          <nav className="space-y-2">
            <div className="flex items-center gap-3 text-white bg-white/20 rounded-lg px-4 py-3">
              <Home className="h-4 w-4" />
              <span>대시보드</span>
            </div>
            <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
              <FileText className="h-4 w-4" />
              <span>변환 기록</span>
            </div>
            <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
              <Settings className="h-4 w-4" />
              <span>설정</span>
            </div>
            <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
              <HelpCircle className="h-4 w-4" />
              <span>도움말</span>
            </div>
          </nav>

          <div className="mt-8 p-4 bg-orange-500/20 rounded-lg border border-orange-400/30">
            <div className="flex items-center gap-2 text-orange-100 mb-2">
              <Zap className="h-4 w-4" />
              <span className="text-sm">CLOVA API</span>
            </div>
            <p className="text-xs text-orange-200/80 mb-3">
              네이버 클로바 음성인식 연동
            </p>
            <div className="text-xs text-orange-200/60">
              실시간 음성→텍스트 변환
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl text-white mb-2">AI 변환 &amp; 요약 도구</h1>
                <p className="text-white/70">음성, 영상, 텍스트를 스마트하게 변환하고 요약해보세요</p>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <Bell className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <Menu className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Main Card */}
            <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-orange-500" />
                  콘텐츠 변환 &amp; 요약
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Tabs */}
                <Tabs defaultValue="upload" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="upload" className="flex items-center gap-2">
                      <Upload className="h-4 w-4" />
                      파일 업로드
                    </TabsTrigger>
                    <TabsTrigger value="youtube" className="flex items-center gap-2">
                      <Youtube className="h-4 w-4" />
                      유튜브 링크
                    </TabsTrigger>
                    <TabsTrigger value="text" className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      텍스트 입력
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="upload" className="space-y-4">
                    <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center hover:border-orange-300 transition-colors">
                      <input
                        type="file"
                        id="file-upload"
                        className="hidden"
                        accept="audio/*,video/*,.txt,.doc,.docx,.pdf"
                        onChange={handleFileUpload}
                      />
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <div className="flex flex-col items-center gap-4">
                          {getFileIcon(selectedFile)}
                          <div>
                            <p className="text-lg mb-2">
                              {selectedFile ? selectedFile.name : '파일을 선택하거나 드래그하여 업로드하세요'}
                            </p>
                            <p className="text-sm text-gray-500">
                              지원 형식: MP3, MP4, WAV, FLAC, OGG (음성 인식용) | TXT, PDF, DOC (텍스트용)
                            </p>
                            {selectedFile && (
                              <p className="text-xs text-gray-400 mt-2">
                                {getFileTypeDescription(selectedFile)} • {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                              </p>
                            )}
                          </div>
                          {selectedFile && (
                            <div className="flex gap-2">
                              <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                              </Badge>
                              {isAudioOrVideoFile(selectedFile) && (
                                <Badge variant="secondary" className="bg-green-100 text-green-800">
                                  음성 인식 가능
                                </Badge>
                              )}
                            </div>
                          )}
                        </div>
                      </label>
                    </div>
                  </TabsContent>

                  <TabsContent value="youtube" className="space-y-4">
                    <div className="flex gap-4">
                      <Input
                        placeholder="유튜브 영상 URL을 입력하세요"
                        value={youtubeUrl}
                        onChange={(e) => setYoutubeUrl(e.target.value)}
                        className="flex-1"
                      />
                      <Button variant="outline">
                        <Youtube className="h-4 w-4 mr-2" />
                        확인
                      </Button>
                    </div>
                    {youtubeUrl && (
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800">✓ 유튜브 링크가 입력되었습니다</p>
                        <p className="text-xs text-blue-600 mt-1">
                          현재 YouTube 처리 기능은 개발 중입니다.
                        </p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="text" className="space-y-4">
                    <Textarea
                      placeholder="변환하거나 요약할 텍스트를 입력하세요..."
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      rows={6}
                      className="resize-none"
                    />
                    {textInput && (
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>글자 수: {textInput.length}</span>
                        <span>단어 수: {textInput.split(/\s+/).filter(word => word.length > 0).length}</span>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>

                {/* Status Messages */}
                {conversionError && (
                  <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <AlertCircle className="h-4 w-4 text-red-500" />
                    <span className="text-sm text-red-700">{conversionError}</span>
                  </div>
                )}
                
                {conversionSuccess && !conversionError && (
                  <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-700">변환이 성공적으로 완료되었습니다!</span>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={handleConvert}
                    disabled={!selectedFile && !youtubeUrl && !textInput || isConverting}
                    className="flex-1 bg-orange-500 hover:bg-orange-600"
                  >
                    {isConverting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        {selectedFile && isAudioOrVideoFile(selectedFile) ? 'CLOVA로 변환 중...' : '변환 중...'}
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        {selectedFile && isAudioOrVideoFile(selectedFile) ? 'CLOVA로 음성 변환' : '텍스트로 변환하기'}
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleSummarize}
                    disabled={!conversionResult && !textInput || isSummarizing}
                    variant="outline"
                    className="flex-1"
                  >
                    {isSummarizing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-400 mr-2"></div>
                        요약 중...
                      </>
                    ) : (
                      <>
                        <BookOpen className="h-4 w-4 mr-2" />
                        AI 요약하기
                      </>
                    )}
                  </Button>
                </div>

                {/* Results */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Conversion Result */}
                  <div className="space-y-3">
                    <h3 className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      변환 결과
                      {selectedFile && isAudioOrVideoFile(selectedFile) && (
                        <Badge variant="outline" className="text-xs">CLOVA STT</Badge>
                      )}
                    </h3>
                    <div className="min-h-[200px] p-4 bg-gray-50 rounded-lg border">
                      {conversionResult ? (
                        <div className="whitespace-pre-wrap text-sm leading-relaxed">
                          {conversionResult}
                        </div>
                      ) : (
                        <div className="h-full flex items-center justify-center text-gray-400">
                          변환 결과가 여기에 표시됩니다
                        </div>
                      )}
                    </div>
                    {conversionResult && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => copyToClipboard(conversionResult)}
                      >
                        결과 복사하기
                      </Button>
                    )}
                  </div>

                  {/* Summary Result */}
                  <div className="space-y-3">
                    <h3 className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4" />
                      요약 결과
                    </h3>
                    <div className="min-h-[200px] p-4 bg-orange-50 rounded-lg border border-orange-200">
                      {summaryResult ? (
                        <div className="whitespace-pre-wrap text-sm leading-relaxed">
                          {summaryResult}
                        </div>
                      ) : (
                        <div className="h-full flex items-center justify-center text-gray-400">
                          요약 결과가 여기에 표시됩니다
                        </div>
                      )}
                    </div>
                    {summaryResult && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => copyToClipboard(summaryResult)}
                      >
                        요약 복사하기
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}