import type { Metadata } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'SmartNote - AI 변환 & 요약 도구',
  description: '음성, 영상, 텍스트를 스마트하게 변환하고 요약하는 AI 도구',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ko">
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}