'use client';

import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { 
  Zap, 
  BookOpen,
  Bell,
  Menu
} from 'lucide-react';
import Sidebar from '../components/sidebar';
import FileUploadSection from '../components/file-upload-section';
import ResultsSection from '../components/results-section';

export default function HomePage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [textInput, setTextInput] = useState('');
  const [conversionResult, setConversionResult] = useState('');
  const [summaryResult, setSummaryResult] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);

  const handleConvert = async () => {
    setIsConverting(true);
    // Mock conversion process
    setTimeout(() => {
      const mockTranscription = `음성/영상이 성공적으로 텍스트로 변환되었습니다.

다음은 변환된 내용입니다:

안녕하세요, 오늘은 인공지능의 발전에 대해 이야기해보겠습니다. 최근 몇 년간 AI 기술은 놀라운 속도로 발전하고 있으며, 특히 자연어 처리 분야에서 큰 진전을 보이고 있습니다.

ChatGPT와 같은 대화형 AI는 일상생활에서 다양한 용도로 활용되고 있으며, 교육, 업무, 창작 활동 등 여러 분야에서 도움을 주고 있습니다.

앞으로 AI 기술은 더욱 발전하여 우리의 삶을 더욱 편리하게 만들어줄 것으로 예상됩니다.`;
      
      setConversionResult(mockTranscription);
      setIsConverting(false);
    }, 2000);
  };

  const handleSummarize = async () => {
    if (!conversionResult && !textInput) return;
    
    setIsSummarizing(true);
    // Mock summarization process
    setTimeout(() => {
      const mockSummary = `📋 요약 결과

🔍 주요 내용:
• 인공지능 기술의 급속한 발전
• 자연어 처리 분야의 혁신적 진전
• ChatGPT 등 대화형 AI의 일상적 활용

🎯 핵심 포인트:
• 교육, 업무, 창작 분야에서의 AI 활용 증가
• 미래 AI 기술의 긍정적 전망
• 생활 편의성 향상에 대한 기대

💡 결론:
AI 기술은 지속적으로 발전하며 인간의 삶을 더욱 풍요롭게 만들어갈 것으로 예상됩니다.`;
      
      setSummaryResult(mockSummary);
      setIsSummarizing(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#6366f1] via-[#8b5cf6] to-[#a855f7] relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-300 rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-300 rounded-full mix-blend-overlay filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="relative z-10 flex h-screen">
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl text-white mb-2">AI 변환 &amp; 요약 도구</h1>
                <p className="text-white/70">음성, 영상, 텍스트를 스마트하게 변환하고 요약해보세요</p>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <Bell className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <Menu className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Main Card */}
            <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-orange-500" />
                  콘텐츠 변환 &amp; 요약
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* File Upload Section */}
                <FileUploadSection
                  selectedFile={selectedFile}
                  setSelectedFile={setSelectedFile}
                  youtubeUrl={youtubeUrl}
                  setYoutubeUrl={setYoutubeUrl}
                  textInput={textInput}
                  setTextInput={setTextInput}
                />

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={handleConvert}
                    disabled={!selectedFile && !youtubeUrl && !textInput || isConverting}
                    className="flex-1 bg-orange-500 hover:bg-orange-600"
                  >
                    {isConverting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        변환 중...
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        텍스트로 변환하기
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleSummarize}
                    disabled={!conversionResult && !textInput || isSummarizing}
                    variant="outline"
                    className="flex-1"
                  >
                    {isSummarizing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-400 mr-2"></div>
                        요약 중...
                      </>
                    ) : (
                      <>
                        <BookOpen className="h-4 w-4 mr-2" />
                        요약하기
                      </>
                    )}
                  </Button>
                </div>

                {/* Results Section */}
                <ResultsSection 
                  conversionResult={conversionResult}
                  summaryResult={summaryResult}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}