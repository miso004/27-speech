'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Upload, 
  FileAudio, 
  FileVideo, 
  FileText, 
  Youtube 
} from 'lucide-react';

interface FileUploadSectionProps {
  selectedFile: File | null;
  setSelectedFile: (file: File | null) => void;
  youtubeUrl: string;
  setYoutubeUrl: (url: string) => void;
  textInput: string;
  setTextInput: (text: string) => void;
}

export default function FileUploadSection({
  selectedFile,
  setSelectedFile,
  youtubeUrl,
  setYoutubeUrl,
  textInput,
  setTextInput
}: FileUploadSectionProps) {
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const getFileIcon = (file: File | null) => {
    if (!file) return <Upload className="h-4 w-4" />;
    
    if (file.type.startsWith('audio/')) return <FileAudio className="h-4 w-4" />;
    if (file.type.startsWith('video/')) return <FileVideo className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  return (
    <Tabs defaultValue="upload" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="upload" className="flex items-center gap-2">
          <Upload className="h-4 w-4" />
          파일 업로드
        </TabsTrigger>
        <TabsTrigger value="youtube" className="flex items-center gap-2">
          <Youtube className="h-4 w-4" />
          유튜브 링크
        </TabsTrigger>
        <TabsTrigger value="text" className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          텍스트 입력
        </TabsTrigger>
      </TabsList>

      <TabsContent value="upload" className="space-y-4">
        <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center hover:border-orange-300 transition-colors">
          <input
            type="file"
            id="file-upload"
            className="hidden"
            accept="audio/*,video/*,.txt,.doc,.docx,.pdf"
            onChange={handleFileUpload}
          />
          <label htmlFor="file-upload" className="cursor-pointer">
            <div className="flex flex-col items-center gap-4">
              {getFileIcon(selectedFile)}
              <div>
                <p className="text-lg mb-2">
                  {selectedFile ? selectedFile.name : '파일을 선택하거나 드래그하여 업로드하세요'}
                </p>
                <p className="text-sm text-gray-500">
                  지원 형식: MP3, MP4, WAV, TXT, PDF, DOC
                </p>
              </div>
              {selectedFile && (
                <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </Badge>
              )}
            </div>
          </label>
        </div>
      </TabsContent>

      <TabsContent value="youtube" className="space-y-4">
        <div className="flex gap-4">
          <Input
            placeholder="유튜브 영상 URL을 입력하세요"
            value={youtubeUrl}
            onChange={(e) => setYoutubeUrl(e.target.value)}
            className="flex-1"
          />
          <Button variant="outline">
            <Youtube className="h-4 w-4 mr-2" />
            확인
          </Button>
        </div>
        {youtubeUrl && (
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">✓ 유튜브 링크가 입력되었습니다</p>
          </div>
        )}
      </TabsContent>

      <TabsContent value="text" className="space-y-4">
        <Textarea
          placeholder="변환하거나 요약할 텍스트를 입력하세요..."
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          rows={6}
          className="resize-none"
        />
        {textInput && (
          <div className="flex justify-between text-sm text-gray-500">
            <span>글자 수: {textInput.length}</span>
            <span>단어 수: {textInput.split(/\s+/).filter(word => word.length > 0).length}</span>
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}