import { Button } from './ui/button';
import { FileText, BookOpen } from 'lucide-react';

interface ResultsSectionProps {
  conversionResult: string;
  summaryResult: string;
}

export default function ResultsSection({ conversionResult, summaryResult }: ResultsSectionProps) {
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      // You could add a toast notification here
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Conversion Result */}
      <div className="space-y-3">
        <h3 className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          변환 결과
        </h3>
        <div className="min-h-[200px] p-4 bg-gray-50 rounded-lg border">
          {conversionResult ? (
            <div className="whitespace-pre-wrap text-sm leading-relaxed">
              {conversionResult}
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-400">
              변환 결과가 여기에 표시됩니다
            </div>
          )}
        </div>
        {conversionResult && (
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={() => copyToClipboard(conversionResult)}
          >
            결과 복사하기
          </Button>
        )}
      </div>

      {/* Summary Result */}
      <div className="space-y-3">
        <h3 className="flex items-center gap-2">
          <BookOpen className="h-4 w-4" />
          요약 결과
        </h3>
        <div className="min-h-[200px] p-4 bg-orange-50 rounded-lg border border-orange-200">
          {summaryResult ? (
            <div className="whitespace-pre-wrap text-sm leading-relaxed">
              {summaryResult}
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-400">
              요약 결과가 여기에 표시됩니다
            </div>
          )}
        </div>
        {summaryResult && (
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={() => copyToClipboard(summaryResult)}
          >
            요약 복사하기
          </Button>
        )}
      </div>
    </div>
  );
}