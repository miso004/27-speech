import { 
  BookOpen, 
  Home, 
  FileText, 
  Settings, 
  HelpCircle, 
  Zap 
} from 'lucide-react';
import { Button } from './ui/button';

export default function Sidebar() {
  return (
    <div className="w-64 bg-white/10 backdrop-blur-sm border-r border-white/20 p-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
          <BookOpen className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-white">SmartNote</h1>
          <p className="text-white/60 text-sm">AI 변환 &amp; 요약</p>
        </div>
      </div>

      <nav className="space-y-2">
        <div className="flex items-center gap-3 text-white bg-white/20 rounded-lg px-4 py-3">
          <Home className="h-4 w-4" />
          <span>대시보드</span>
        </div>
        <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
          <FileText className="h-4 w-4" />
          <span>변환 기록</span>
        </div>
        <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
          <Settings className="h-4 w-4" />
          <span>설정</span>
        </div>
        <div className="flex items-center gap-3 text-white/70 hover:text-white hover:bg-white/10 rounded-lg px-4 py-3 transition-colors cursor-pointer">
          <HelpCircle className="h-4 w-4" />
          <span>도움말</span>
        </div>
      </nav>

      <div className="mt-8 p-4 bg-orange-500/20 rounded-lg border border-orange-400/30">
        <div className="flex items-center gap-2 text-orange-100 mb-2">
          <Zap className="h-4 w-4" />
          <span className="text-sm">Pro 버전</span>
        </div>
        <p className="text-xs text-orange-200/80 mb-3">
          더 많은 기능을 이용하세요
        </p>
        <Button size="sm" className="w-full bg-orange-500 hover:bg-orange-600 text-white">
          업그레이드
        </Button>
      </div>
    </div>
  );
}