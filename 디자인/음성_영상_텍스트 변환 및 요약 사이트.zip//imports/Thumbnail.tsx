import imgImage1 from "figma:asset/397ef95175a71af4596bd525ef367a055c271315.png";

export default function Thumbnail() {
  return (
    <div className="bg-[#d8dae7] relative size-full" data-name="Thumbnail">
      <div
        className="absolute bg-center bg-cover bg-no-repeat h-[1200px] left-0 top-0 w-[1600px]"
        data-name="image 1"
        style={{ backgroundImage: `url('${imgImage1}')` }}
      />
    </div>
  );
}