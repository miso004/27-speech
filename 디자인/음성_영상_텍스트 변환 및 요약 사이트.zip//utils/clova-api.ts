// CLOVA Speech-to-Text API 연동 함수
const CLOVA_URL = 'https://clovaspeech-gw.ncloud.com/external/v1/11685/d3a6f1ef48abba27bf857f15438d9c40f516f73dca06c9b23cabcbd4e6bfa190/recognizer/upload';
    const API_KEY = '08rrxysx5w';
    const API_SECRET = '6UDkPTSxIFI7gYBXAD94O3x5lZuhbfS079sTM6TL';
// const CLOVA_CLIENT_ID = '08rrxysx5w';
// const CLOVA_CLIENT_SECRET = '6UDkPTSxIFI7gYBXAD94O3x5lZuhbfS079sTM6TL';
// const CLOVA_API_URL = 'https://naveropenapi.apigw.ntruss.com/recog/v1/stt';

export interface ClovaSpeechResult {
  text: string;
  confidence?: number;
}

export interface ClovaSpeechError {
  error: string;
  message: string;
}

export async function convertSpeechToText(audioFile: File): Promise<ClovaSpeechResult> {
  try {
    // 지원하는 파일 형식 확인
    const supportedFormats = ['audio/wav', 'audio/mp3', 'audio/mpeg', 'audio/flac', 'audio/ogg'];
    if (!supportedFormats.includes(audioFile.type)) {
      throw new Error(`지원하지 않는 파일 형식입니다. 지원 형식: WAV, MP3, FLAC, OGG`);
    }

    // 파일 크기 확인 (60MB 제한)
    const maxSize = 60 * 1024 * 1024; // 60MB
    if (audioFile.size > maxSize) {
      throw new Error('파일 크기가 너무 큽니다. 최대 60MB까지 지원됩니다.');
    }

    // FormData 생성
    const formData = new FormData();
    formData.append('media', audioFile);

    // API 호출
    const response = await fetch(CLOVA_API_URL, {
      method: 'POST',
      headers: {
         'Accept': 'application/json', 
        'X-CLOVASPEECH-API-KEY': 'b62c91334c54498ab81bda8fe5f39930'
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `API 호출 실패: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    
    // API 응답 구조에 따른 텍스트 추출
    if (result.text) {
      return {
        text: result.text,
        confidence: result.confidence
      };
    } else {
      throw new Error('음성 인식 결과를 받을 수 없습니다.');
    }

  } catch (error) {
    console.error('CLOVA Speech-to-Text API 오류:', error);
    
    if (error instanceof Error) {
      throw error;
    } else {
      throw new Error('알 수 없는 오류가 발생했습니다.');
    }
  }
}

// 파일 형식이 음성/영상 파일인지 확인하는 함수
export function isAudioOrVideoFile(file: File): boolean {
  return file.type.startsWith('audio/') || file.type.startsWith('video/');
}

// 파일 형식을 사용자 친화적인 문자열로 변환
export function getFileTypeDescription(file: File): string {
  if (file.type.startsWith('audio/')) {
    return '음성 파일';
  } else if (file.type.startsWith('video/')) {
    return '영상 파일';
  } else {
    return '파일';
  }
}